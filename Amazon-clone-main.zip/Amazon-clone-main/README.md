# Amazon-CLone-Webpage

This project is a Amazon clone webpage created as part of my Full Stack Developer course at Apna College Delta Batch. It has been an exciting and challenging experience to build this project, and I have learned a lot throughout the process.

# Learning Journey
During the development of this project, I encountered various obstacles and faced numerous challenges. However, I overcame them by referring to YouTube videos and tutorials. I would like to express my heartfelt gratitude to Shraddha Khapra for her exceptional teaching skills, which made the learning process much simpler and more enjoyable.

# Project Details
Instead of creating a typical landing page, I decided to build a Amazon home page. I found it to be a rewarding experience as it allowed me to delve deeper into the functionality and intricacies of the Amazon platform.

# Acknowledgements
I would like to extend my sincere thanks to Shraddha Khapra for her outstanding guidance and support throughout the course. Her expertise and dedication have been invaluable in shaping my understanding of full-stack development.

I am also grateful to Apna College for providing a comprehensive learning program that has equipped me with the necessary skills to undertake projects like this Spotify clone webpage.

# Conclusion
Building this Amazon clone webpage has been a fulfilling journey that has enhanced my understanding of web development. I am proud of the accomplishments I have achieved through this project, and I look forward to applying the knowledge and skills I have gained in future endeavors.

Thank you, Shraddha Khapra ma'am, and Apna College, for the incredible learning experience!